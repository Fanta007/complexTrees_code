s(1,:) = 'cc08lamx4cel01pp';
s(2,:) = 'cc08lamx4cel02pp';
s(3,:) = 'cc08lamxxcel02pp';
s(4,:) = 'cc11lam05cel02pp';
s(5,:) = 'cc11lamxxcel01pp';